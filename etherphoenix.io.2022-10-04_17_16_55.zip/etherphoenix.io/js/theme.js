// const themeButton = document.getElementById('theme-button')
const bodyTheme1 = document.getElementsByClassName('light-theme')

themeButton.addEventListener('click',function(){
    bodyTheme.classList.toggle('light-theme')
    bodyTheme.classList.toggle('dark-theme')
})